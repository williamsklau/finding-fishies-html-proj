package com.example.fish;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;


public class MainActivity2 extends AppCompatActivity {
    Button Activity_button;
    Button btn_start;
    int HighestScore;
    DatabaseHelper helper = new DatabaseHelper(MainActivity2.this);
    WebView mywebview;
    int testing = 0;
    WebAppInterface JS_control;
    String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);


        Activity_button = (Button)findViewById(R.id.activity);
        btn_start = findViewById(R.id.bt_start);

        username = getIntent().getStringExtra("current_user");
        HighestScore = Integer.parseInt(getIntent().getStringExtra("user_score"));

        JS_control = new WebAppInterface(this);

        mywebview = findViewById(R.id.webView);
        mywebview.getSettings().setJavaScriptEnabled(true);
        mywebview.loadUrl("file:///android_asset/main.html");

        mywebview.addJavascriptInterface(JS_control,"App");


        TextView score_text_view = findViewById(R.id.score_display);
        Button score_display = findViewById(R.id.score_display);

        Thread myThread = new Thread(myRunnable);
        myThread.start();

        score_display.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //mywebview.loadUrl("javascript:sendScore();");

                // JS method calls must be made on a separate thread (otherwise they cannot be called)
                mywebview.post(new Runnable() {
                    @Override
                    public void run() {
                        mywebview.loadUrl("javascript:sendScore();");
                        final Handler handler = new Handler();
                        handler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                // Do something after 5s = 5000ms
                                Toast.makeText(MainActivity2.this,"got this" + JS_control.getScore(),Toast.LENGTH_SHORT).show();
                            }
                        }, 500);
                        helper.update_score(username,JS_control.getScore());
                    }
                });
            }
        });

        btn_start.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v)
            {
                mywebview.post(new Runnable() {
                    @Override
                    public void run() {
                        mywebview.loadUrl("javascript:startGame();");
                        Toast.makeText(MainActivity2.this,Integer.toString(testing),Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });

        mywebview.setWebChromeClient(new WebChromeClient(){
            public boolean onJsAlert(WebView view, String url, String message, final JsResult result) {
                android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(MainActivity2.this);
                // Set the message show for the Alert time
                builder.setMessage("Some fishies are hungry. Game Over.");

                // Set Alert Title
                builder.setTitle("Oh Noooooo");

                // Set Cancelable false
                // for when the user clicks on the outside
                // the Dialog Box then it will remain show
                builder.setCancelable(false);

                // Set the positive button with yes name
                // OnClickListener method is use of
                // DialogInterface interface.
                mywebview.loadUrl("javascript:sendScore();");
                final Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        // Do something after 5s = 5000ms
                        if(JS_control.getScore()>HighestScore)
                        {

                            helper.update_score(username,JS_control.getScore());
                            HighestScore = JS_control.getScore();
                            Toast.makeText(MainActivity2.this,"got this" + JS_control.getScore(),Toast.LENGTH_SHORT).show();
                        }
                    }
                }, 500);

                builder.setPositiveButton("Try again?", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog,int which)
                    {
                        mywebview.loadUrl("javascript:startGame();");
                    }
                });

                // Set the Negative button with No name
                // OnClickListener method is use
                // of DialogInterface interface.
                builder.setNegativeButton("I want to Leave", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which)
                    {

                        // If user click no
                        // then dialog box is canceled.
                        Intent intent = new Intent(MainActivity2.this, MainActivity.class);

                        // start the activity connect to the specified class
                        MainActivity2.this.startActivity(intent);
                    }
                });

                // Create the Alert dialog
                AlertDialog alertDialog = builder.create();

                // Show the Alert Dialog box
                alertDialog.show();
                result.confirm();
                return true;
            }
        });

        Activity_button.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v)
            {

                // Intents are objects of the android.content.Intent type. Your code can send them
                // to the Android system defining the components you are targeting.
                // Intent to start an activity called SecondActivity with the following code:

                Intent intent = new Intent(MainActivity2.this, MainActivity.class);

                // start the activity connect to the specified class
                startActivity(intent);
            }
        });
    }

    Runnable myRunnable = new Runnable() {
        @Override
        public void run() {
            }
        };
}
