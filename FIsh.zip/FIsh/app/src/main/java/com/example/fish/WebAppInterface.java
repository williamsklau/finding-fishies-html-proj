package com.example.fish;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.webkit.JavascriptInterface;
import android.widget.Toast;

public class WebAppInterface {
    int score;
    Boolean end;
    Context mContext;
    DatabaseHelper helper;
    String username;
    int highestScore;

    public WebAppInterface(Context c) {
        mContext = c;
        this.score = 0;
        this.end = false;
    }

    public Boolean getEndgame() {
        return end;
    }

    public void setEnd(Boolean end) {
        this.end = end;
    }

    public int getScore() {
        return score;
    }


    @JavascriptInterface
    public void receiveValueFromJs(String str) {
    //do something useful with str
        //Toast.makeText(mContext, "Received Value from JS: " + str,Toast.LENGTH_SHORT).show();
        score = Integer.parseInt(str);
    }

    @JavascriptInterface
    public void endgame() {
        //do something useful with str
        //Toast.makeText(mContext, "Received Value from JS: end game",Toast.LENGTH_SHORT).show();
        end = true;

//        //got this from https://www.geeksforgeeks.org/android-alert-dialog-box-and-how-to-create-it/
//        AlertDialog.Builder builder
//                = new AlertDialog
//                .Builder(mContext);
//        // Set the message show for the Alert time
//        builder.setMessage("Some fishies are hungry. Game Over.");
//
//        // Set Alert Title
//        builder.setTitle("Oh Noooooo");
//
//        // Set Cancelable false
//        // for when the user clicks on the outside
//        // the Dialog Box then it will remain show
//        builder.setCancelable(false);
//
//        // Set the positive button with yes name
//        // OnClickListener method is use of
//        // DialogInterface interface.
//
//        builder
//                .setPositiveButton(
//                        "Try again?",
//                        new DialogInterface
//                                .OnClickListener() {
//
//                            @Override
//                            public void onClick(DialogInterface dialog,
//                                                int which)
//                            {
//                                // When the user click yes button
//                                // then app will close
//                            }
//                        });
//
//        // Set the Negative button with No name
//        // OnClickListener method is use
//        // of DialogInterface interface.
//        builder
//                .setNegativeButton(
//                        "No, I want to Leave",
//                        new DialogInterface
//                                .OnClickListener() {
//
//                            @Override
//                            public void onClick(DialogInterface dialog,
//                                                int which)
//                            {
//
//                                // If user click no
//                                // then dialog box is canceled.
//                                Intent intent = new Intent(mContext, MainActivity.class);
//
//                                // start the activity connect to the specified class
//                                mContext.startActivity(intent);
//                            }
//                        });
//
//        // Create the Alert dialog
//        AlertDialog alertDialog = builder.create();
//
//        // Show the Alert Dialog box
//        alertDialog.show();
    }
}
