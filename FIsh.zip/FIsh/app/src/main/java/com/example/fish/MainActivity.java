package com.example.fish;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
//import android.support.v7.app.AppCompatActivity;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {
    Button Activity2_button;
    EditText et_name;
    EditText et_pass;
    Button btn_register;
    Button btn_login;
    Button btn_viewAll;
    Button btn_update;
    DatabaseHelper helper = new DatabaseHelper(MainActivity.this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Activity2_button = (Button)findViewById(R.id.activity2);

        et_name = findViewById(R.id.et_username);
        et_pass = findViewById(R.id.et_password);
        btn_login = findViewById(R.id.bt_login);
        btn_register = findViewById(R.id.bt_register);
        btn_viewAll = findViewById(R.id.bt_showAll);
        btn_update = findViewById(R.id.bt_update);

        btn_update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                helper.update_score("what123",12);
            }
        });

        btn_viewAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String title = new String();
                StringBuffer buffer = new StringBuffer();
                //DatabaseHelper helper = new DatabaseHelper(MainActivity.this);
                Toast.makeText(MainActivity.this,"Welcome ",Toast.LENGTH_SHORT).show();
                Cursor res = helper.getAllData();
                if(res.getCount()==0){
                    title = "Error";
                    buffer.append("nothing to show ;(");
                }else{

                    while(res.moveToNext()){
                        buffer.append("User Name:"+res.getString(0)+"\n");
                        buffer.append("Score:"+res.getString(2)+"\n\n");
                        title = "Data";
                    }
                }
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setCancelable(true);
                builder.setTitle(title);
                builder.setMessage(buffer.toString());
                builder.show();
            }
        });

        btn_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                UserModel model = new UserModel(et_name.getText().toString(),et_pass.getText().toString(),0);
                //DatabaseHelper helper = new DatabaseHelper(MainActivity.this);
                boolean success = helper.register(model);
                if(success){
                    Toast.makeText(MainActivity.this,"Welcome "+et_name.getText().toString() + "!",Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(MainActivity.this,"This name is taken :(",Toast.LENGTH_SHORT).show();
                }

            }
        });

        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //DatabaseHelper helper = new DatabaseHelper(MainActivity.this);
                boolean acccess = helper.check(et_name.getText().toString(),et_pass.getText().toString());
                if(acccess){
                    //Toast.makeText(MainActivity.this,"Acccess: granted",Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(MainActivity.this, MainActivity2.class);
                    intent.putExtra("current_user",et_name.getText().toString());
                    intent.putExtra("user_score",helper.getScore(et_name.getText().toString()));
                    Toast.makeText(MainActivity.this,helper.getScore(et_name.getText().toString()),Toast.LENGTH_SHORT).show();
                    // start the activity connect to the specified class
                    startActivity(intent);
                }else{
                    Toast.makeText(MainActivity.this,"Acess: Denied",Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Add_button add clicklistener
        Activity2_button.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v)
            {

                // Intents are objects of the android.content.Intent type. Your code can send them
                // to the Android system defining the components you are targeting.
                // Intent to start an activity called SecondActivity with the following code:


            }
        });
    }
}